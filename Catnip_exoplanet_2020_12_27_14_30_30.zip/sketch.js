function setup() {
  createCanvas(400, 400);
  background(20);
}

function draw() {
  fill('white')
  ellipse(200, 200, 200, 100);
  
  fill('black')
  ellipse(200, 200, 180, 80);
  
  fill('white')
  rect(180, 155,50, 90);
  
  fill('black')
  rect(230, 180, 70, 50);
}